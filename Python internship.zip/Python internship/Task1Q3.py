n=int(input("enter the number"))
p=1
for i in range(n,1,-1):
    p=p*i

print(p)