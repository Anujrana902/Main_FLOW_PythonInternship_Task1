#reverse a string
st=input("enter the string")
rev=st[::-1]
print(st)
print(rev)
