n=int(input("enter the value if n"))
a=0
b=1
for i in range(n):
    print(a)
    t=a
    a=b
    b=t+b
    