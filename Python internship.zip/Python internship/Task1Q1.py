# ADD TWO NUMBERS
a=int(input("enter a"))
b=int(input("enter b"))
print(a+b)
# to check wheather the number is seven or odd
c=int(input("enter the number="))
if c%2==0:
    print("the number is even")
else:
    print("the number is odd")


