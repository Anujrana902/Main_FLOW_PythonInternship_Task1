st=input("enter the string")
rev=st[::-1]
if(st==rev):
    print("string is palindrome")
else:
    print("string is not palindrome")