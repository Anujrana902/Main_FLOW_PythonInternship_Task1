n=int(input("enter the number"))
s=0
t=n
x=len(str(n))
while t>0:
    d=t%10
    s+=d ** x
    t //=10

if n==sum:
    print("Armstrong no.")
else:
    print("not Armstrong no.")
